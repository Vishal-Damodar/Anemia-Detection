import React, { useState } from "react";
import axios from "axios";

function Signup() {
  const [params, setParams] = useState({
    name: "",
    email: "",
    password: "",
    password2: "",
    role:"asha"
  });
  const onsubmit = () => {
    console.log("done");
    if (params.password !== params.password2){

      console.log(params)
      return alert("Passwords do not match");
    }
    axios
      .post("http://localhost:3006/auth/register", params)
      .then((res) => console.log(res))
      .catch((err) => console.log(err));
  };
  return (
    <div>
      <div class="bg-grey-lighter min-h-screen flex flex-col">
        <div class="container max-w-sm mx-auto flex-1 flex flex-col items-center justify-center px-2">
          <div class="bg-white px-6 py-8 rounded shadow-md text-black w-full">
            <h1 class="mb-8 text-3xl text-center">Sign up</h1>
            <input
              onChange={(e) =>
                setParams((prevStat) => ({ ...prevStat, name: e.target.value }))
              }
              type="text"
              class="block border border-grey-light w-full p-3 rounded mb-4"
              name="fullname"
              placeholder="Full Name"
            />

            <input
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  email: e.target.value,
                }))
              }
              type="text"
              class="block border border-grey-light w-full p-3 rounded mb-4"
              name="email"
              placeholder="Email"
            />
            <input
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  phone: e.target.value,
                }))
              }
              type="number"
              class="block border border-grey-light w-full p-3 rounded mb-4"
              name="number"
              placeholder="phone number"
            />
            <input
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  addhar: e.target.value,
                }))
              }
              type="number" 
              class="block border border-grey-light w-full p-3 rounded mb-4"
              name="aadhar"
              placeholder="addhar number"
            />
            <input
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  password: e.target.value,
                }))
              }
              type="password"
              class="block border border-grey-light w-full p-3 rounded mb-4"
              name="password"
              placeholder="Password"
            />
            <input
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  password2: e.target.value,
                }))
              }
              type="password"
              class="block border border-grey-light w-full p-3 rounded mb-4"
              name="confirm_password"
              placeholder="Confirm Password"
            />
            <div>
            <div className="m-4 mb-8">
            <span className="gap mr-6">Gender:</span>
                <label class="inline-flex items-center mr-6">
                    <input
                        type="radio"
                        class="form-checkbox"
                        name="gender"
                        value="male"
                        checked={params.gender === "male"}
                        onChange={()=>setParams({...params, gender:"male"})}
                    />
                    <span class="ml-2 text-gray-800">Male</span>
                </label>
                <label class="inline-flex items-center">
                    <input
                        type="radio"
                        class="form-checkbox"
                        name="gender"
                        value="female"
                        checked={params.gender === "female"}
                        onChange={()=>setParams({...params, gender:"female"})}
                    />
                    <span class="ml-2 text-gray-800">Female</span>
                </label>
            </div>
            </div>
              
            <button onClick={() => onsubmit()}
              type="submit"
              class=" w-full block rounded-lg bg-gray-800 px-8 py-3 text-center text-sm font-semibold text-white outline-none ring-gray-300 transition duration-100 hover:bg-gray-700 focus-visible:ring active:bg-gray-600 md:text-base"
            >
              Create Account
            </button>

            <div class="text-center text-sm text-grey-dark mt-4">
              By signing up, you agree to the
              <a
                class="no-underline border-b border-grey-dark text-grey-dark"
                href="#"
              >
                Terms of Service
              </a>{" "}
              and
              <a
                class="no-underline border-b border-grey-dark text-grey-dark"
                href="#"
              >
                Privacy Policy
              </a>
            </div>
          </div>

          <div class="text-grey-dark mt-6">
            Already have an account?
            <button
              class="no-underline border-b border-blue text-blue"
            >
              Log in
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Signup;
