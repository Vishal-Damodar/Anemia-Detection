import React from "react";
import pic from "../components/anemia-test.webp";
import { Link } from "react-router-dom";

const Landing = () => {
  const active = "user";
  return (
    <div className="h-[100dvh] flex items-center ">
      {/* <img className="h-full w-1/2" src={pic} /> */}
      <div className="justify-center items-center flex flex-auto">
        <Link
          class=" w-full text-center py-1 px-4 bg-gray-500 text-white focus:outline-none"
          to={`${active === "user" ? "login" : "userlogin"}`} >
          LogIn
        </Link>
        <Link
          class=" w-full bg-black text-white text-center py-1 px-4 focus:outline-none"
          to={"Signup"} >
          SignUp
        </Link>
      </div>
    </div>
  );
};

export default Landing;
