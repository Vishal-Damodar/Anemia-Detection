import React, { useState } from "react";
import axios from "axios";

const PatientTest = () => {
  const onSubmit = () => {
    axios
      .post("http://localhost:3006/asha_login", params, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((res) => console.log(res))
      .catch((err) => console.log(err));
  };
  const [params, setParams] = useState({
    lname: "",
    fname: "",
    ashaEmail: "sameer@gmail.com",
  });
  return (
    <React.Fragment>
      <div class="bg-white py-6 sm:py-8 lg:py-12">
        <div class="mx-auto max-w-screen-2xl px-4 md:px-8">
          <div class="mb-10 md:mb-16">
            <h2 class="mb-4 text-center text-2xl font-bold text-gray-800 md:mb-6 lg:text-3xl">
              Test A Patient
            </h2>

            <p class="mx-auto max-w-screen-md text-center text-gray-500 md:text-lg">
              This is a section of some simple filler text, also known as
              placeholder text. It shares some characteristics of a real written
              text but is random or otherwise generated.
            </p>
          </div>
    <div className="mx-auto grid max-w-screen-md gap-4 sm:grid-cols-2">

          <div>
            <label
              for="first-name"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              First name*
            </label>
            <input
              name="first-name"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  fname: e.target.value,
                  name:
                    e.target.value + prevStat.lname == undefined
                      ? ""
                      : prevStat.lname,
                }))
              }
              type="text"
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div>
            <label
              for="last-name"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              {" "}
              Last name*
            </label>
            <input
              name="last-name"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  lname: e.target.value,
                  name:
                    prevStat.fname == undefined
                      ? ""
                      : prevStat.fname + e.target.value,
                }))
              }
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div>
            <label
              for="first-name"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              Addhar Number*
            </label>
            <input
              name="first-name"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  aadhar: e.target.value,
                }))
              }
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div>
            <label
              for="last-name"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              Phone Number*
            </label>
            <input
              name="last-name"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  phone: e.target.value,
                }))
              }
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div>
            <label
              for="first-name"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              City*
            </label>
            <input
              name="first-name"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  city: e.target.value,
                }))
              }
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div>
            <label
              for="last-name"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              State*
            </label>
            <input
              name="last-name"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  state: e.target.value,
                }))
              }
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div className="w-full rounded border px-3 py-2 text-gray-800 outline-none ">
            <span className="gap mr-6 mb-2 inline-block text-sm text-gray-800 sm:text-base ">Gender*</span>
            <label class="inline-flex items-center mr-6">
              <input
                type="radio"
                class="form-checkbox"
                name="gender"
                value="male"
                checked={params.gender === "male"}
                onChange={() => setParams({ ...params, gender: "male" })}
              />
              <span class="ml-2 text-gray-800">Male</span>
            </label>
            <label class="inline-flex items-center">
              <input
                type="radio"
                class="  checked:text-black"
                name="gender"
                value="female"
                checked={params.gender === "female"}
                onChange={() => setParams({ ...params, gender: "female" })}
              />
              <span class="ml-2 text-gray-800">Female</span>
            </label>
          </div>

          <div class="sm:col-span-2">
            <label
              for="company"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              Choose eye photo*
            </label>
            <input
              name="company"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  eyeImageData: e.target.files[0],
                }))
              }
              type="file"
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div class="sm:col-span-2">
            <label
              for="email"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              Choose nail photo*
            </label>
            <input
              name="email"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  nailImageData: e.target.files[0],
                }))
              }
              type="file"
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div class="sm:col-span-2">
            <label
              for="subject"
              class="mb-2 inline-block text-sm text-gray-800 sm:text-base"
            >
              Choose tongue photo*
            </label>
            <input
              name="subject"
              onChange={(e) =>
                setParams((prevStat) => ({
                  ...prevStat,
                  tongueImageData: e.target.files[0],
                }))
              }
              type="file"
              class="w-full rounded border bg-gray-50 px-3 py-2 text-gray-800 outline-none ring-indigo-300 transition duration-100 focus:ring"
            />
          </div>

          <div class="flex items-center justify-between sm:col-span-2">
            <button
              onClick={() => onSubmit()}
              class="inline-block rounded-lg bg-indigo-500 px-8 py-3 text-center text-sm font-semibold text-white outline-none ring-indigo-300 transition duration-100 hover:bg-indigo-600 focus-visible:ring active:bg-indigo-700 md:text-base"
            >
              Send
            </button>
          </div>
        </div>
    </div>
      </div>
    </React.Fragment>
  );
};

export default PatientTest;
